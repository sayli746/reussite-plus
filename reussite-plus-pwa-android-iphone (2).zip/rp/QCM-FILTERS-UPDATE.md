# Correctif des filtres QCM — Réussite+

## Changements
- Relié les filtres à une logique isolée et testable (`qcm-filters.js`).
- Le choix du niveau et de la matière charge les banques correspondantes.
- Les chapitres proposés sont actualisés selon la matière et la difficulté sélectionnées.
- Le filtre chapitre compare les valeurs en normalisant la casse et les accents.
- Le filtre difficulté accepte les libellés `facile`, `intermediaire`/`intermédiaire`, `difficile`, ainsi que quelques alias usuels.
- Le compteur de questions et les volumes sélectionnables s'actualisent immédiatement.
- Le bouton de lancement est désactivé si aucune question ne correspond.
- Le mode « questions ratées uniquement » est appliqué avant le lancement.
- Les doublons d'identifiants sont retirés de la sélection.
- En cas d'échec de chargement d'une banque, les autres banques disponibles restent utilisables et l'interface indique celles qui n'ont pas pu être chargées.

## Tests exécutés
- `node --check app.js` : réussi.
- `node --check qcm-filters.js` : réussi.
- `node scripts/validate-data.js` : réussi, 4 800 questions et 4 800 identifiants uniques, 0 erreur et 0 avertissement.
- `node tests/qcm-filters.test.js` : réussi (chapitre, difficulté, accents, mode questions ratées, dédoublonnage).
- `node tests/smoke-test.js` : réussi.

## Limite
Les tests unitaires et de structure passent. Un test visuel de bout en bout dans un navigateur et un déploiement réel Netlify n'ont pas été exécutés dans cette session.
