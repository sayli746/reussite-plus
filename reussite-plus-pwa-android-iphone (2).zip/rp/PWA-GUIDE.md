# Réussite+ — version PWA

## Ce qui a été ajouté
- `manifest.json` complété (nom, démarrage, affichage autonome, couleurs et icônes).
- Icônes PNG 192×192, 512×512 et icône Apple Touch.
- Enregistrement du service worker depuis `index.html`.
- `sw.js` met en cache les ressources publiques du site et les fichiers demandés avec succès. Après une première visite en ligne, les pages et données déjà chargées peuvent donc rester accessibles hors connexion.
- Les appels externes, les fonctions Netlify et les requêtes non-GET ne sont pas mis en cache.
- En-têtes Netlify pour éviter de conserver indéfiniment une ancienne version du service worker et du manifeste.

## Limites importantes
- Il faut ouvrir le site au moins une fois en ligne pour installer la PWA et mettre en cache les ressources.
- Hors connexion, seules les pages et données déjà mises en cache sont disponibles. Une fiche ou une matière jamais ouverte peut manquer.
- La connexion, l'inscription, la synchronisation Supabase et les fonctions serveur nécessitent Internet.
- Le navigateur peut supprimer des données mises en cache, notamment si l'espace est limité. Le mode hors connexion ne remplace pas une sauvegarde.
- iOS et Android n'affichent pas toujours les mêmes invites d'installation. Sur iPhone, utiliser Safari > Partager > Sur l'écran d'accueil.
- Aucun déploiement sur Netlify n'a été effectué par cette modification. Il faut tester l'installation, les pages hors ligne et les mises à jour sur de vrais appareils après publication.

## Déploiement
Publier le contenu du dossier du projet (`rp/`) à la racine du site Netlify, de manière à ce que `index.html`, `sw.js`, `manifest.json`, `app.js`, `styles.css`, `icons/` et `data/` soient accessibles à la racine. Ne déployer que si les tests fonctionnels habituels passent.

## Test manuel recommandé
1. Déployer la version et ouvrir le site en HTTPS.
2. Recharger une fois en ligne, attendre quelques secondes.
3. Ouvrir plusieurs pages et fiches de cours.
4. Installer sur Android via Chrome, ou sur iPhone via Safari > Partager > Sur l'écran d'accueil.
5. Activer le mode avion et rouvrir l'application ; vérifier l'accueil et les ressources déjà consultées.
6. Désactiver le mode avion et vérifier que les données et la version se mettent à jour.
