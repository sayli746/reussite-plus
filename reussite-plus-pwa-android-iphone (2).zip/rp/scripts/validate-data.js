#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const qroot = path.join(root, "data", "qcm");
const expectedLevels = ["3e", "seconde", "premiere", "terminale"];
let errors = 0, warnings = 0, total = 0;
const seenIds = new Map();
const report = [];
const normalize = s => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g," ").trim();
function fail(msg){ console.error("ERREUR:",msg); errors++; }
function warn(msg){ console.warn("AVERTISSEMENT:",msg); warnings++; }
for (const level of expectedLevels) {
  const dir = path.join(qroot, level);
  if (!fs.existsSync(dir)) { fail(`Dossier manquant: ${dir}`); continue; }
  for (const file of fs.readdirSync(dir).filter(f=>f.endsWith(".json")).sort()) {
    const p = path.join(dir,file);
    let data;
    try { data=JSON.parse(fs.readFileSync(p,"utf8")); } catch(e) { fail(`${p}: JSON invalide (${e.message})`); continue; }
    if (!Array.isArray(data)) { fail(`${p}: la racine doit être un tableau`); continue; }
    const key = `${level}/${file.replace(/\.json$/,"")}`;
    total += data.length;
    report.push({key,count:data.length});
    if (data.length !== 100) fail(`${key}: ${data.length}/100 questions attendues`);
    const localStems = new Map();
    for (const [i,q] of data.entries()) {
      const loc = `${p} question ${i+1}`;
      for (const f of ["id","niveau","matiere","chapitre","difficulte","type","question","options","correctIndex","explanation","tags"])
        if (!(f in q)) fail(`${loc}: champ ${f} manquant`);
      if (q.niveau!==level) fail(`${loc}: niveau ${q.niveau} incohérent avec ${level}`);
      if (!Array.isArray(q.options)||q.options.length<3||q.options.length>5) fail(`${loc}: options doit contenir 3 à 5 propositions`);
      if (!Array.isArray(q.options)||!Number.isInteger(q.correctIndex)||q.correctIndex<0||q.correctIndex>=q.options.length) fail(`${loc}: correctIndex invalide`);
      if (typeof q.explanation!=="string"||!q.explanation.trim()) fail(`${loc}: explication manquante`);
      if (!q.question?.trim()) fail(`${loc}: énoncé vide`);
      if (!Array.isArray(q.tags)||!q.tags.length) fail(`${loc}: tags manquants`);
      if (seenIds.has(q.id)) fail(`Identifiant dupliqué ${q.id}: ${seenIds.get(q.id)} et ${loc}`);
      else seenIds.set(q.id,loc);
      const norm=normalize(q.question);
      if (norm.length>10) {
        if (localStems.has(norm)) fail(`Énoncé identique dans ${key}: ${localStems.get(norm)} et ${loc}`);
        else localStems.set(norm,loc);
      }
      if (!["facile","intermediaire","difficile"].includes(q.difficulte)) fail(`${loc}: difficulté inconnue ${q.difficulte}`);
      if (Array.isArray(q.options) && new Set(q.options.map(x=>String(x).trim())).size !== q.options.length) fail(`${loc}: propositions de réponse dupliquées`);
    }
  }
}
const subjectsPath=path.join(root,"data","subjects.json");
try {
 const subjects=JSON.parse(fs.readFileSync(subjectsPath,"utf8"));
 for(const level of expectedLevels) for(const s of subjects[level]||[]) {
   const file=path.join(qroot,level,`${s.id}.json`);
   if(!fs.existsSync(file)) fail(`Banque absente pour ${level}/${s.id}`);
 }
} catch(e){ fail(`subjects.json invalide: ${e.message}`); }
console.log("\nBANQUES QCM — COMPTAGE RÉEL");
for(const r of report) console.log(`${r.key.padEnd(36)} ${String(r.count).padStart(3)} question(s)`);
console.log(`\nTotal réel : ${total} question(s) ; ${seenIds.size} identifiant(s) unique(s).`);
console.log(`Erreurs : ${errors} ; avertissements : ${warnings}.`);
if(errors) process.exitCode=1;
