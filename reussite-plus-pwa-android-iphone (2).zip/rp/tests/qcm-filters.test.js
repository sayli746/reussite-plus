import assert from "node:assert/strict";
import { filterQcmQuestions, getChapterCounts, normalizeDifficulty } from "../qcm-filters.js";

const questions = [
  { id: "q1", chapitre: "Les fractions", difficulte: "facile", question: "Q1" },
  { id: "q2", chapitre: "Les fractions", difficulte: "intermediaire", question: "Q2" },
  { id: "q3", chapitre: "Géométrie", difficulte: "difficile", question: "Q3" },
  { id: "q4", chapitre: "Geometrie", difficulte: "intermédiaire", question: "Q4" },
  { id: "q1", chapitre: "Les fractions", difficulte: "facile", question: "Q1 duplicate id" }
];

assert.equal(normalizeDifficulty("Intermédiaire"), "intermediaire");
assert.equal(filterQcmQuestions(questions, { chapter: "les FRACTIONS" }).length, 2);
assert.deepEqual(filterQcmQuestions(questions, { difficulty: "difficile" }).map(q => q.id), ["q3"]);
assert.deepEqual(filterQcmQuestions(questions, { chapter: "Géométrie", difficulty: "intermédiaire" }).map(q => q.id), ["q4"]);
assert.deepEqual(filterQcmQuestions(questions, { reviewOnly: true, wrongIds: ["q2", "q3"] }).map(q => q.id), ["q2", "q3"]);
assert.deepEqual(getChapterCounts(questions, "facile"), [{ value: "Les fractions", count: 2 }]);
assert.equal(filterQcmQuestions(questions).length, 4, "duplicate question IDs should only appear once");
console.log("Tests des filtres QCM réussis : chapitre, difficulté, accents, questions ratées et dédoublonnage.");
