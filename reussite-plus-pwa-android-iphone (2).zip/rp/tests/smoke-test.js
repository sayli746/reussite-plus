import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
for(const f of ["index.html","styles.css","app.js","README.md","data/subjects.json","data/inventory.json"]) assert.ok(fs.existsSync(path.join(root,f)),`missing ${f}`);
const html=fs.readFileSync(path.join(root,"index.html"),"utf8");
const app=fs.readFileSync(path.join(root,"app.js"),"utf8");
assert.match(html,/href="#erreurs"/,"error notebook navigation missing");
assert.match(html,/href="#planning"/,"planner navigation missing");
assert.match(html,/href="#examens"/,"mock exam navigation missing");
assert.match(app,/function renderErrorNotebook\(/,"error notebook page missing");
assert.match(app,/async function renderPlanner\(/,"planner page missing");
assert.match(app,/async function renderExams\(/,"mock exams page missing");
assert.match(app,/EXAMEN BLANC TERMINÉ/,"exam completion label missing");
assert.match(app,/getCorrectIndex\(q\)/,"answer compatibility helper missing");
assert.match(app,/filterQcmQuestions/,"QCM filters utility is not connected");
assert.match(app,/getChapterCounts/,"chapter availability counts are not connected");
assert.match(app,/async function syncProgressToCloud\(/,"cloud sync helper missing");
assert.match(app,/id="sync-progress"/,"manual cloud sync control missing");
const subjects=JSON.parse(fs.readFileSync(path.join(root,"data/subjects.json"),"utf8"));
const levels=["3e","seconde","premiere","terminale"];
let n=0, courseCount=0;
const normalize=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g," ").trim();
for(const l of levels){
 assert.ok(Array.isArray(subjects[l]),`subject level ${l}`);
 for(const s of subjects[l]){
  const file=path.join(root,"data","qcm",l,`${s.id}.json`);
  assert.ok(fs.existsSync(file),`missing QCM file ${l}/${s.id}`);
  const qs=JSON.parse(fs.readFileSync(file,"utf8"));
  assert.ok(Array.isArray(qs));
  assert.equal(qs.length,100,`expected 100 questions for ${l}/${s.id}`);
  const stems=new Set();
  for(const q of qs){
   const normalizedStem=normalize(q.question);
   assert.ok(!stems.has(normalizedStem),`duplicate question stem in ${l}/${s.id}: ${q.question}`);
   stems.add(normalizedStem);
   assert.equal(new Set(q.options.map(x=>String(x).trim())).size,q.options.length,`duplicate options in ${l}/${s.id}: ${q.question}`);
   assert.equal(q.niveau,l);
   assert.ok(q.options.length>=3 && q.options.length<=5);
   assert.ok(Number.isInteger(q.correctIndex)&&q.correctIndex>=0&&q.correctIndex<q.options.length);
   assert.ok(q.explanation.length>0);
   n++;
  }
  const courseFile=path.join(root,"data","courses",l,`${s.id}.json`);
  assert.ok(fs.existsSync(courseFile),`missing revision sheet ${l}/${s.id}`);
  const cards=JSON.parse(fs.readFileSync(courseFile,"utf8"));
  assert.ok(Array.isArray(cards)&&cards.length>0,`empty revision sheet ${l}/${s.id}`);
  for(const c of cards){
   for(const key of ["titre","cours","definitions","methode_etapes","resume","exercices"]) assert.ok(c[key]!==undefined,`missing ${key} in ${l}/${s.id}`);
   courseCount++;
  }
 }
}
assert.ok(fs.existsSync(path.join(root,"data","true-false","questions.json")));
assert.ok(fs.existsSync(path.join(root,"data","culture-generale","questions.json")));
const inventory=JSON.parse(fs.readFileSync(path.join(root,"data/inventory.json"),"utf8"));
assert.equal(inventory.actual_qcm_questions,n);
assert.equal(n,4800);
assert.equal(inventory.actual_courses,courseCount);
console.log(`Fiches de révision vérifiées : ${courseCount}.`);
console.log(`Smoke tests réussis : ${n} questions QCM structurées, 100 par matière/niveau, ${levels.length} niveaux.`);
