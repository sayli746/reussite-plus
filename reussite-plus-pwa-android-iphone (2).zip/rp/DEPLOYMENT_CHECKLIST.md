# Checklist de déploiement — Réussite+

## Avant le déploiement
- [ ] Garder une copie du projet original.
- [ ] Décompresser l’archive complète.
- [ ] Vérifier que `index.html`, `app.js`, `styles.css`, `data/` et `netlify/functions/` sont présents.
- [ ] Exécuter les commandes de test du README.

## Netlify
- [ ] Déployer le dossier complet (pas seulement `index.html`).
- [ ] Confirmer que `netlify.toml` est à la racine publiée.
- [ ] Définir `SUPABASE_URL`.
- [ ] Définir `SUPABASE_ANON_KEY`.
- [ ] Définir `SUPABASE_SERVICE_ROLE_KEY` comme variable serveur secrète uniquement.
- [ ] Redéployer après modification des variables.
- [ ] Vérifier les logs de déploiement et des fonctions.

## Supabase
- [ ] Exécuter `data/supabase-schema.sql` dans le SQL Editor.
- [ ] Vérifier que `profiles` et `user_progress` existent.
- [ ] Vérifier que RLS est activé et que les politiques sont présentes.
- [ ] Configurer les URL de site et de redirection Auth pour le domaine Netlify.
- [ ] Vérifier les e-mails de confirmation.
- [ ] Ne jamais publier la clé service role.

## Tests manuels après publication
- [ ] Ouvrir l’accueil et changer de niveau.
- [ ] Ouvrir une fiche de révision dans chaque niveau.
- [ ] Faire un QCM et vérifier une réponse juste et une réponse fausse.
- [ ] Vérifier le score, le carnet d’erreurs, les favoris et le tableau de bord.
- [ ] Tester l’inscription avec une adresse e-mail de test.
- [ ] Confirmer l’adresse e-mail puis se connecter.
- [ ] Cliquer volontairement sur « Synchroniser ma progression » et vérifier l’enregistrement dans Supabase.
- [ ] Vérifier sur mobile et ordinateur.
- [ ] Consulter les journaux en cas d’échec.

## Limites connues
La synchronisation n’a pas été testée sur le compte Supabase réel depuis l’environnement de préparation. Les QCM signalés `reviewStatus: "à relire pédagogiquement"` doivent être revus avant de considérer les contenus comme certifiés.
