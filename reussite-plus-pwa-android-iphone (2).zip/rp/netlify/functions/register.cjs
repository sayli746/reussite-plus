
const { createClient } = require("@supabase/supabase-js");

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
  };

  const reply = (statusCode, body) => ({
    statusCode,
    headers,
    body: JSON.stringify(body),
  });

  if (event.httpMethod !== "POST") {
    return reply(405, { error: "Méthode non autorisée." });
  }

  let data;
  try {
    data = JSON.parse(event.body || "{}");
  } catch {
    return reply(400, { error: "Données invalides." });
  }

  const username = String(data.username || "").trim();
  const email = String(data.email || "").trim().toLowerCase();
  const password = String(data.password || "");

  if (!/^[a-zA-Z0-9_-]{3,20}$/.test(username)) {
    return reply(400, {
      error: "Le pseudo doit contenir 3 à 20 caractères : lettres, chiffres, _ ou -.",
    });
  }

  if (
    email.length > 254 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  ) {
    return reply(400, { error: "Adresse e-mail invalide." });
  }

  if (password.length < 8 || password.length > 128) {
    return reply(400, {
      error: "Le mot de passe doit contenir entre 8 et 128 caractères.",
    });
  }

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    return reply(500, { error: "Configuration serveur incomplète." });
  }

  const supabase = createClient(url, key, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  let userId = null;

  try {
    const { data: result, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: false,
    });

    if (error) {
      return reply(400, {
        error: "Inscription impossible. Vérifie l'adresse e-mail ou essaie de te connecter.",
      });
    }

    userId = result.user.id;
    const { error: emailError } = await supabase.auth.resend({
  type: "signup",
  email,
  options: {
    emailRedirectTo: "https://reussiteplusprojetsemifinal.netlify.app"
  }
});

if (emailError) {
  await supabase.auth.admin.deleteUser(userId);
  return reply(500, {
    error: "Impossible d'envoyer l'e-mail de confirmation. Réessaie plus tard."
  });
}

    const { error: profileError } = await supabase
      .from("profiles")
      .insert({ id: userId, username });

    if (profileError) {
      await supabase.auth.admin.deleteUser(userId);
      return reply(400, {
        error: "Ce pseudo est peut-être déjà utilisé. Choisis-en un autre.",
      });
    }

    return reply(201, {
      message: "Compte créé. Vérifie ta boîte e-mail pour confirmer ton adresse.",
    });
  } catch {
    if (userId) {
      await supabase.auth.admin.deleteUser(userId);
    }
    return reply(500, { error: "Erreur serveur lors de l'inscription." });
  }
};
