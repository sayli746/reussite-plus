
const { createClient } = require("@supabase/supabase-js");

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
  };

  const reply = (statusCode, body) => ({
    statusCode,
    headers,
    body: JSON.stringify(body),
  });

  if (event.httpMethod !== "POST") {
    return reply(405, { error: "Méthode non autorisée." });
  }

  let data;
  try {
    data = JSON.parse(event.body || "{}");
  } catch {
    return reply(400, { error: "Données invalides." });
  }

  const email = String(data.email || "").trim().toLowerCase();
  const password = String(data.password || "");

  if (!email || !password) {
    return reply(400, {
      error: "Entre ton e-mail et ton mot de passe.",
    });
  }

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY;

  if (!url || !key) {
    return reply(500, {
      error: "Configuration serveur incomplète.",
    });
  }

  const supabase = createClient(url, key, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  try {
    const { data: result, error } =
      await supabase.auth.signInWithPassword({
        email,
        password,
      });

    if (error || !result.user) {
      return reply(401, {
        error: "E-mail ou mot de passe incorrect.",
      });
    }

    if (!result.user.email_confirmed_at) {
      return reply(403, {
        error: "Confirme ton adresse e-mail avant de te connecter.",
      });
    }

    return reply(200, {
      message: "Connexion réussie.",
      user: {
        id: result.user.id,
        email: result.user.email,
      },
      session: result.session,
    });
  } catch {
    return reply(500, {
      error: "Erreur lors de la connexion.",
    });
  }
};

