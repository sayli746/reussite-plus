# Audit final du contenu et du code

Voir `FINAL_STATUS.md` pour les tests et les limites, et `data/content-audit.json` pour les décomptes par matière et niveau.

## Contrôles automatisés
- 48 banques QCM.
- 100 questions dans chaque banque.
- 4 800 questions au total.
- 100 énoncés distincts par banque après normalisation des accents et de la ponctuation.
- 240 fiches de révision.
- Vérification de l'unicité des identifiants, des index de correction, des champs requis et des propositions répétées.
- Vérification syntaxique de l'application et des fonctions Netlify.

## Limites pédagogiques
L'outil de validation ne peut pas décider si un distracteur est pédagogiquement optimal, si une explication couvre toutes les exceptions, ni si chaque notion est au bon niveau. Une partie des questions ajoutées est signalée par `reviewStatus` et doit être relue. Les fiches ajoutées sont des synthèses et ne sont pas une certification de conformité exhaustive aux programmes.

## Sources officielles
- https://www.education.gouv.fr/les-programmes-du-college-470408
- https://www.education.gouv.fr/reussir-au-lycee/les-programmes-du-lycee-general-et-technologique-9812
- https://eduscol.education.fr/
