# Réussite+ — modifications de cette version

## Modifications intégrées
- Ajout de la page « Planning » : créer, cocher, supprimer des sessions de révision et supprimer les tâches terminées. Données stockées dans le navigateur (`localStorage`), sans service payant.
- Ajout de la page « Examens blancs » : choisir niveau, matière (ou toutes les matières), nombre de questions et durée. Les questions sont sélectionnées dans les banques QCM existantes, avec chronomètre et correction finale.
- Les corrections en cours affichent la bonne réponse lorsqu'une réponse est incorrecte.
- Liens vers Planning et Examens blancs dans la navigation ; raccourcis depuis le tableau de bord.
- Ajout de métadonnées de référencement, URL canonique, `robots.txt` et `sitemap.xml` pour la page d'accueil.
- Conservation des pages et fonctionnalités existantes : cours, QCM, mini-jeux, culture générale, progression, carnet d'erreurs, favoris, profil et confidentialité.

## Vérifications exécutées
- `node --check app.js` : réussi.
- `node tests/qcm-filters.test.js` : réussi.
- `node tests/smoke-test.js` : réussi.
- `node scripts/validate-data.js` : 4 800 questions et 4 800 identifiants uniques, 0 erreur structurelle signalée.

## Limites à connaître
- Les tests automatiques vérifient la structure et les règles testées, pas la justesse pédagogique de chaque question.
- L'audit existant indique que 3 847 questions portent le statut « à relire pédagogiquement ». Une relecture par des personnes compétentes reste nécessaire.
- Les examens blancs sont des assemblages de QCM existants, pas des sujets officiels complets ni des examens couvrant nécessairement tout le programme.
- Le planning, les favoris et les résultats du mode invité restent locaux à chaque navigateur/appareil.
- Le site n'a pas été déployé ni testé dans un vrai navigateur sur l'URL publique au cours de cette modification. Faire un test manuel sur mobile et ordinateur avant de remplacer la version en ligne.
- Les métadonnées SEO et le sitemap aident les moteurs à comprendre le site mais ne garantissent pas son indexation ni une hausse du trafic.
