
import { filterQcmQuestions, getChapterCounts } from "./qcm-filters.js";

let supabaseClient = null;

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const state = {level:localStorage.getItem("rp-level")||"3e", subjects:{}, courses:{}, qcm:[], session:null, answers:[], index:0, selected:null, results:JSON.parse(localStorage.getItem("rp-results")||"[]"), favorites:JSON.parse(localStorage.getItem("rp-favorites")||"[]"), recent:JSON.parse(localStorage.getItem("rp-recent")||"[]"), gameTimer:null, examTimer:null, seconds:60, score:0};
const view=$("#view");
const levelNames={"3e":"Troisième (3e)","seconde":"Seconde","premiere":"Première","terminale":"Terminale"};
const safe=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function load(url){const r=await fetch(url);if(!r.ok)throw new Error(`Impossible de charger ${url} (${r.status})`);return r.json()}
function toast(s){const t=$("#toast");t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function allResults(){return state.results}
function stats(){const total=state.results.reduce((n,r)=>n+r.total,0), correct=state.results.reduce((n,r)=>n+r.score,0);return {total,correct,pct:total?Math.round(correct/total*100):0}}
function subjectById(id){return (state.subjects[state.level]||[]).find(s=>s.id===id)}
function levelControl(){return `<div class="field"><label for="level-select">NIVEAU SCOLAIRE</label><select id="level-select">${Object.entries(levelNames).map(([k,v])=>`<option value="${k}" ${state.level===k?"selected":""}>${v}</option>`).join("")}</select></div>`}
function subjectControl(selected=""){return `<div class="field"><label for="subject-select">MATIÈRE</label><select id="subject-select"><option value="">Toutes les matières</option>${(state.subjects[state.level]||[]).map(s=>`<option value="${safe(s.id)}" ${selected===s.id?"selected":""}>${safe(s.name)}</option>`).join("")}</select></div>`}
function bindLevel(){const el=$("#level-select");if(el)el.addEventListener("change",async e=>{state.level=e.target.value;localStorage.setItem("rp-level",state.level);await loadLevel();route()})}
function navActive(hash){$$('#nav a').forEach(a=>a.classList.toggle("active",a.getAttribute("href")===hash))}
function route(){clearInterval(state.gameTimer);state.gameTimer=null;let h=location.hash.slice(1)||"accueil";if(!h.startsWith("qcm-run")){clearInterval(state.examTimer);state.examTimer=null}navActive("#"+h);$("#nav").classList.remove("open");if(h.startsWith("qcm-run"))return renderQuiz();switch(h){case"accueil":renderHome();break;case"cours":renderCourses();break;case"qcm":renderQcmSetup();break;case"jeux":renderGames();break;case"culture":renderCulture();break;case"tableau-de-bord":renderDashboard();break;case"erreurs":renderErrorNotebook();break;case"planning":renderPlanner();break;case"controles":renderControles();break;case"examens":renderExams();break;case"vrai-faux":renderTF();break;case"favoris":renderFavorites();break;case"profil":renderProfile();break;case"confidentialite":renderPrivacy();break;default:renderHome()}}
function header(title,desc){return `<div class="eyebrow">RÉUSSITE+ · ${safe(levelNames[state.level])}</div><h1 class="page-title">${title}</h1><p class="lead">${desc}</p>`}
function renderHome(){const s=stats(), subs=state.subjects[state.level]||[];view.innerHTML=`<section class="hero"><div><div class="eyebrow">TON ESPACE DE RÉVISION</div><h1>Révise aujourd'hui,<br><em>réussis demain.</em></h1><p>Des cours clairs, des QCM corrigés et des défis pour progresser à ton rythme. Chaque bonne réponse te rapproche de ton objectif.</p><div class="actions"><a class="btn tealbtn" href="#qcm">Commencer un QCM ↗</a><a class="btn light" href="#cours">Explorer les cours</a></div><div class="filters" style="margin-top:24px;margin-bottom:0">${levelControl()}</div></div><div class="ring" style="--pct:${s.pct}%"><div><strong>${s.pct}%</strong><small>réussite globale</small></div></div></section>
<section class="section"><div class="head"><div><h2>Ton tableau de bord</h2><p>Des chiffres calculés à partir de tes activités enregistrées.</p></div><a class="badge" href="#tableau-de-bord">Voir ma progression →</a></div><div class="statgrid"><div class="card stat"><span>Questions répondues</span><strong>${s.total}</strong><span>tous les QCM</span></div><div class="card stat"><span>Bonnes réponses</span><strong>${s.correct}</strong><span>réponses correctes</span></div><div class="card stat"><span>Taux de réussite</span><strong>${s.pct}%</strong><span>sur les tentatives</span></div><div class="card stat"><span>Favoris</span><strong>${state.favorites.length}</strong><span>questions sauvegardées</span></div></div></section>
<section class="section"><div class="head"><div><h2>Choisis une matière</h2><p>Les matières affichées correspondent au niveau sélectionné.</p></div><a class="badge" href="#cours">Tous les cours →</a></div><div class="grid">${subs.map(x=>`<article class="card subject" tabindex="0" role="link" data-course="${safe(x.id)}"><div class="symbol ${safe(x.color)}">${safe(x.icon)}</div><h3>${safe(x.name)}</h3><p>${safe(x.topics.slice(0,3).join(" · "))}</p><span class="tiny">Cours & QCM →</span></article>`).join("")}</div></section>
<section class="section columns"><div class="panel"><div class="head"><div><h2>Reprendre mes révisions</h2><p>Les dernières activités sur cet appareil.</p></div></div>${state.recent.length?state.recent.slice(0,4).map(r=>`<div class="activity"><span class="badge">${safe(r.level)}</span><div style="flex:1"><b>${safe(r.subject)}</b><div class="tiny">${safe(r.date)}</div></div><b>${r.score}/${r.total}</b></div>`).join(""):`<div class="empty">Aucune activité pour le moment.<b>Lance ton premier QCM !</b><a class="btn primary" href="#qcm">Commencer</a></div>`}</div><div class="panel"><h3>À toi de jouer !</h3><p class="lead">Varie les formats pour mieux mémoriser.</p><div class="actions"><a class="btn primary" href="#jeux">Découvrir les mini-jeux</a><a class="btn outline" href="#vrai-faux">Vrai ou faux</a><a class="btn outline" href="#culture">Culture générale</a></div></div></section>`;
bindLevel();$$("[data-course]").forEach(el=>{const go=()=>{localStorage.setItem("rp-course",el.dataset.course);location.hash="cours"};el.addEventListener("click",go);el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();go()}})})}
async function loadLevel(){state.subjects=await load("data/subjects.json");}
async function renderCourses(){view.innerHTML=header("Cours & fiches","Choisis une matière et retrouve une fiche structurée avec objectifs, définitions, exemples, méthodes et exercices.")+`<div class="filters">${levelControl()}${subjectControl(localStorage.getItem("rp-course")||"")}<div class="field"><label for="course-search">RECHERCHER UN COURS</label><input id="course-search" placeholder="Titre, notion, chapitre…"></div></div><div id="course-results" class="course-list"></div>`;bindLevel();const run=async()=>{const id=$("#subject-select").value, q=$("#course-search").value.toLowerCase();let rows=[];for(const s of state.subjects[state.level]||[]){if(id&&s.id!==id)continue;try{const cs=await load(`data/courses/${state.level}/${s.id}.json`);for(const c of cs)if((c.titre+" "+c.chapitre+" "+c.cours).toLowerCase().includes(q))rows.push({s,c})}catch(e){console.warn(e)}}$("#course-results").innerHTML=rows.length?rows.map(({s,c})=>`<article class="card course"><span class="badge">${safe(s.name)}</span><h3>${safe(c.titre)}</h3><p>${safe(c.cours.slice(0,230))}…</p><p class="tiny">Chapitre : ${safe(c.chapitre)}</p><button class="btn primary" data-open-course="${safe(s.id)}">Lire la fiche →</button><button class="btn outline" data-course-qcm="${safe(s.id)}">S'entraîner</button></article>`).join(""):`<div class="empty">Aucun cours ne correspond à cette recherche.</div>`;$$("[data-open-course]").forEach(b=>b.onclick=()=>openCourse(b.dataset.openCourse));$$("[data-course-qcm]").forEach(b=>b.onclick=()=>{localStorage.setItem("rp-course",b.dataset.courseQcm);location.hash="qcm"})};$("#subject-select").onchange=run;$("#course-search").oninput=run;await run()}
async function openCourse(id){try{const c=(await load(`data/courses/${state.level}/${id}.json`))[0];const s=subjectById(id);view.innerHTML=`<button class="btn outline" id="back-courses">← Retour aux cours</button><div class="course-body">${header(s?.name||id,c.titre)}<div class="panel"><h2>Objectifs d'apprentissage</h2><ul>${c.objectifs.map(x=>`<li>${safe(x)}</li>`).join("")}</ul><h3>Prérequis</h3><ul>${c.prerequis.map(x=>`<li>${safe(x)}</li>`).join("")}</ul></div><div class="panel"><h2>Le cours</h2><p>${safe(c.cours)}</p></div><div class="panel"><h2>Définitions importantes</h2>${c.definitions.map(d=>`<p><b>${safe(d.terme)} :</b> ${safe(d.definition)}</p>`).join("")}</div><div class="panel"><h2>Propriétés à retenir</h2><ul>${c.proprietes.map(x=>`<li>${safe(x)}</li>`).join("")}</ul></div><div class="panel"><h2>Exemples résolus</h2><ul>${c.exemples_resolus.map(x=>`<li>${safe(x)}</li>`).join("")}</ul></div><div class="panel"><h2>Méthode étape par étape</h2><ol>${c.methode_etapes.map(x=>`<li>${safe(x)}</li>`).join("")}</ol></div><div class="panel"><h2>Erreurs fréquentes</h2><ul>${c.erreurs_frequentes.map(x=>`<li>${safe(x)}</li>`).join("")}</ul></div><div class="panel"><h2>Résumé</h2><div class="callout">${safe(c.resume)}</div><h3>À mémoriser</h3><ul>${c.a_memoriser.map(x=>`<li>${safe(x)}</li>`).join("")}</ul></div><div class="panel"><h2>Exercice d'application</h2>${c.exercices.map(x=>`<p><b>${safe(x.question)}</b></p><details><summary>Voir la correction</summary><p>${safe(x.correction)}</p></details>`).join("")}<div class="actions"><button class="btn primary" id="course-quiz">Faire un QCM sur cette matière</button></div><p class="tiny">${safe(c.statut)}</p></div></div>`;$("#back-courses").onclick=()=>location.hash="cours";$("#course-quiz").onclick=()=>{localStorage.setItem("rp-course",id);location.hash="qcm"}}catch(e){view.innerHTML=`<div class="empty">Impossible de charger cette fiche. <button class="btn outline" onclick="location.hash='cours'">Retour</button></div>`}}
async function renderQcmSetup(){
  const savedSubject=localStorage.getItem("rp-course")||"";
  const validSubject=(state.subjects[state.level]||[]).some(s=>s.id===savedSubject)?savedSubject:"";
  view.innerHTML=header("Entraînement QCM","Choisis précisément la matière, le chapitre et la difficulté. Le nombre disponible se met à jour avant le lancement.")+
  `<div class="panel"><div class="filters">${levelControl()}${subjectControl(validSubject)}<div class="field"><label for="chapter">CHAPITRE</label><select id="chapter"><option value="">Tous les chapitres</option></select></div><div class="field"><label for="difficulty">DIFFICULTÉ</label><select id="difficulty"><option value="">Toutes les difficultés</option><option value="facile">Facile</option><option value="intermediaire">Intermédiaire</option><option value="difficile">Difficile</option></select></div><div class="field"><label for="amount">NOMBRE DE QUESTIONS</label><select id="amount">${[5,10,20,50,75,100].map(n=>`<option value="${n}">${n} questions</option>`).join("")}</select></div></div><p id="available" class="lead" aria-live="polite">Chargement des questions disponibles…</p><p id="filter-summary" class="tiny"></p><label><input id="shuffle" type="checkbox" checked> Mélanger les questions</label><label style="display:block;margin-top:10px"><input id="review-mode" type="checkbox"> Réviser uniquement les questions ratées</label><div class="actions"><button id="start-quiz" class="btn primary" disabled>Lancer le QCM →</button><a class="btn outline" href="#favoris">Mes favoris</a><a class="btn outline" href="#planning">Mon planning</a><a class="btn outline" href="#examens">Examens blancs</a></div></div><section class="section"><div class="head"><div><h2>Derniers résultats</h2><p>Historique local de tes tentatives.</p></div></div><div class="panel">${state.recent.length?state.recent.slice(0,5).map(r=>`<div class="activity"><span>${safe(r.subject)}</span><span style="flex:1">${safe(r.date)}</span><b>${r.score}/${r.total}</b></div>`).join(""):`<div class="empty">Tes résultats apparaîtront ici après ton premier QCM.</div>`}</div></section>`;
  bindLevel();

  const chapterSelect=$("#chapter");
  const subjectSelect=$("#subject-select");
  const difficultySelect=$("#difficulty");
  const amountSelect=$("#amount");
  const reviewMode=$("#review-mode");
  const startButton=$("#start-quiz");
  let bankQuestions=[];
  let bankErrors=[];
  const cache=new Map();
  const getBanks=async()=>{
    const level=state.level;
    const selectedId=subjectSelect.value;
    const subjects=(state.subjects[level]||[]).filter(s=>!selectedId||s.id===selectedId);
    const loaded=await Promise.all(subjects.map(async s=>{
      const key=`${level}/${s.id}`;
      if(!cache.has(key))cache.set(key,load(`data/qcm/${level}/${s.id}.json`));
      try{return {subject:s.name,questions:await cache.get(key)}}
      catch(error){cache.delete(key);return {subject:s.name,error}}
    }));
    bankErrors=loaded.filter(item=>item.error).map(item=>item.subject);
    return loaded.flatMap(item=>item.questions||[]);
  };
  const matchingQuestions=()=>filterQcmQuestions(bankQuestions,{
    chapter:chapterSelect.value,
    difficulty:difficultySelect.value,
    reviewOnly:reviewMode.checked,
    wrongIds:state.results.flatMap(r=>r.wrongIds||[])
  });
  const updateChapterOptions=()=>{
    const previous=chapterSelect.value;
    const chapters=getChapterCounts(bankQuestions,difficultySelect.value);
    chapterSelect.innerHTML='<option value="">Tous les chapitres</option>'+chapters.map(({value,count})=>`<option value="${safe(value)}">${safe(value)} (${count})</option>`).join("");
    if(chapters.some(ch=>ch.value===previous))chapterSelect.value=previous;
    else chapterSelect.value="";
  };
  const updateAvailability=()=>{
    const qs=matchingQuestions();
    $("#available").textContent=bankErrors.length
      ?`${qs.length} question(s) correspondent à tes filtres. Banques non chargées : ${bankErrors.join(", ")}.`
      :`${qs.length} question(s) correspondent exactement à tes filtres.`;
    $("#filter-summary").textContent=[
      subjectSelect.value?(subjectById(subjectSelect.value)?.name||subjectSelect.value):"Toutes les matières",
      chapterSelect.value||"Tous les chapitres",
      difficultySelect.value?({facile:"Facile",intermediaire:"Intermédiaire",difficile:"Difficile"}[difficultySelect.value]||difficultySelect.value):"Toutes les difficultés",
      reviewMode.checked?"Questions ratées uniquement":"Toutes les questions"
    ].join(" · ");
    const available=qs.length;
    [...amountSelect.options].forEach(option=>{option.disabled=Number(option.value)>available});
    if(available>0){
      const enabled=[...amountSelect.options].filter(option=>!option.disabled);
      if(!enabled.some(option=>option.value===amountSelect.value))amountSelect.value=enabled[enabled.length-1].value;
    }
    startButton.disabled=available===0;
    startButton.textContent=available===0?"Aucune question pour ces filtres":"Lancer le QCM →";
  };
  const refresh=async({reload=true}={})=>{
    startButton.disabled=true;
    if(reload){
      try{bankQuestions=await getBanks()}
      catch(error){bankQuestions=[];bankErrors=["chargement des données"];console.error("Chargement des banques QCM impossible",error)}
    }
    updateChapterOptions();
    updateAvailability();
  };
  subjectSelect.addEventListener("change",()=>{if(subjectSelect.value)localStorage.setItem("rp-course",subjectSelect.value);else localStorage.removeItem("rp-course");chapterSelect.value="";refresh()});
  difficultySelect.addEventListener("change",()=>{updateChapterOptions();updateAvailability()});
  chapterSelect.addEventListener("change",updateAvailability);
  reviewMode.addEventListener("change",updateAvailability);
  amountSelect.addEventListener("change",updateAvailability);
  $("#start-quiz").onclick=async()=>{
    const qs=matchingQuestions();
    if(!qs.length){toast("Aucune question ne correspond à ces filtres.");return}
    let selected=qs.slice();
    if($("#shuffle").checked)selected.sort(()=>Math.random()-.5);
    selected=selected.slice(0,Math.min(Number(amountSelect.value)||5,selected.length));
    if(!selected.length){toast("Aucune question disponible pour cette sélection.");return}
    state.session={questions:selected,subject:subjectSelect.value?(subjectById(subjectSelect.value)?.name||subjectSelect.value):"Toutes les matières",level:state.level,started:Date.now(),kind:"qcm",filters:{chapter:chapterSelect.value||"",difficulty:difficultySelect.value||"",reviewOnly:reviewMode.checked}};
    state.answers=selected.map(()=>null);state.index=0;state.selected=null;location.hash="qcm-run";
  };
  await refresh();
}
function renderQuiz(){if(!state.session||!state.session.questions.length){location.hash="qcm";return}const qs=state.session.questions;if(state.index>=qs.length){finishQuiz();return}const q=qs[state.index],answer=state.answers[state.index];
const correctIndex=getCorrectIndex(q);if(state.session.kind==="exam"&&state.session.deadline){clearInterval(state.examTimer);const updateExamClock=()=>{const left=Math.max(0,Math.ceil((state.session.deadline-Date.now())/1000));const el=$("#exam-clock");if(el)el.textContent=`Temps restant : ${Math.floor(left/60)} min ${String(left%60).padStart(2,"0")} s`;if(left<=0){clearInterval(state.examTimer);state.examTimer=null;state.index=qs.length;finishQuiz()}};updateExamClock();if(!state.session)return;state.examTimer=setInterval(updateExamClock,1000)}const examClock=state.session.kind==="exam"?`<p class="badge" id="exam-clock" aria-live="polite"></p>`:"";view.innerHTML=`<button class="btn outline" id="quit">← Quitter le QCM</button>${examClock}<article class="question" style="margin-top:15px"><div class="qtop"><span>${safe(state.session.subject)} · ${safe(q.chapitre)}</span><span>Question ${state.index+1}/${qs.length}</span></div><div class="qbar"><span style="width:${(state.index+1)/qs.length*100}%"></span></div><span class="badge">${safe(q.difficulte)}</span><h2>${safe(q.question)}</h2><div class="options">${q.options.map((o,i)=>`<button class="option ${answer!==null&&i===correctIndex?"correct":""} ${answer===i&&i!==correctIndex?"wrong":""} ${state.selected===i?"selected":""}" data-option="${i}" ${answer!==null?"disabled":""}><span class="letter">${String.fromCharCode(65+i)}</span><span>${safe(o)}</span></button>`).join("")}</div>${answer!==null?`<div class="feedback ${answer===correctIndex?"good":"bad"}"><b>${answer===correctIndex?"Bonne réponse !":"Pas tout à fait."}</b><br>${answer!==correctIndex?`<br><b>Bonne réponse :</b> ${safe(q.options[correctIndex]??"Correction indisponible")}<br>`:""}${safe(getExplanation(q))}</div>`:""}<div class="qactions"><button class="btn outline" id="previous" ${state.index===0?"disabled":""}>← Précédente</button>${answer===null?`<button class="btn primary" id="validate" ${state.selected===null?"disabled":""}>Valider</button>`:`<button class="btn primary" id="next">${state.index===qs.length-1?"Voir mon résultat":"Suivante →"}</button>`}</div><div style="margin-top:14px"><button class="btn outline" id="favorite">${state.favorites.includes(q.id)?"★ Retirer des favoris":"☆ Ajouter aux favoris"}</button></div></article>`;$("#quit").onclick=()=>{if(confirm("Quitter ce QCM ? Le résultat ne sera pas enregistré.")){state.session=null;location.hash="qcm"}};$$("[data-option]").forEach(b=>b.onclick=()=>{if(state.answers[state.index]===null){state.selected=+b.dataset.option;renderQuiz()}});$("#validate")?.addEventListener("click",()=>{if(state.selected===null)return;state.answers[state.index]=state.selected;state.selected=null;renderQuiz()});$("#next")?.addEventListener("click",()=>{state.index++;state.selected=null;renderQuiz()});$("#previous").onclick=()=>{if(state.index>0){state.index--;state.selected=state.answers[state.index];renderQuiz()}};$("#favorite").onclick=()=>{if(state.favorites.includes(q.id))state.favorites=state.favorites.filter(x=>x!==q.id);else state.favorites.push(q.id);localStorage.setItem("rp-favorites",JSON.stringify(state.favorites));renderQuiz()}}

function getCorrectIndex(q) {
  if (Number.isInteger(q.correctIndex)) return q.correctIndex;

  if (typeof q.reponse === "string" && Array.isArray(q.options)) {
    return q.options.findIndex(
      option => option.trim() === q.reponse.trim()
    );
  }

  return -1;
}

function getExplanation(q) {
  return q.explication ?? q.explanation ?? "";
}
function finishQuiz(){
  clearInterval(state.examTimer);state.examTimer=null;
  const wasExam=state.session?.kind==="exam";
  const qs=state.session.questions;
  let score=0;
  const wrong=[];
  qs.forEach((q,i)=>{
    if(state.answers[i]===getCorrectIndex(q)) score++;
    else wrong.push(q.id);
  });
  const record={
    date:new Date().toLocaleString("fr-FR"),
    level:state.session.level,
    subject:state.session.subject,
    score,
    total:qs.length,
    wrongIds:wrong,
    kind:state.session.kind||"qcm"
  };
  state.results.push(record);
  state.recent.unshift(record);
  state.recent=state.recent.slice(0,20);
  localStorage.setItem("rp-results",JSON.stringify(state.results));
  localStorage.setItem("rp-recent",JSON.stringify(state.recent));
  state.session=null;
  view.innerHTML=`<div class="panel score"><div class="eyebrow">${wasExam?"EXAMEN BLANC TERMINÉ":"QCM TERMINÉ"}</div><h1>Bien joué !</h1><strong>${score} / ${qs.length}</strong><p class="lead">${qs.length?Math.round(score/qs.length*100):0} % de réussite · continue à t'entraîner pour progresser.</p><div class="actions" style="justify-content:center"><button class="btn primary" id="retry-wrong" ${wrong.length?"":"disabled"}>Refaire mes erreurs (${wrong.length})</button><a class="btn outline" href="#qcm">Nouveau QCM</a><a class="btn outline" href="#tableau-de-bord">Voir ma progression</a></div></div><section class="section"><h2>Correction détaillée</h2>${qs.map((q,i)=>{const correctIndex=getCorrectIndex(q);return `<div class="panel" style="margin-bottom:12px"><span class="badge">${state.answers[i]===correctIndex?"Correct":"À revoir"}</span><h3>${safe(q.question)}</h3><p><b>Ta réponse :</b> ${safe(q.options[state.answers[i]]??"Sans réponse")}</p><p><b>Bonne réponse :</b> ${safe(q.options[correctIndex]??"Réponse indisponible")}</p><p>${safe(getExplanation(q))}</p></div>`}).join("")}</section>`;
  $("#retry-wrong").onclick=()=>{
    state.session={questions:qs.filter((q,i)=>state.answers[i]!==getCorrectIndex(q)),subject:"Erreurs à revoir",level:state.level,kind:"review"};
    state.answers=state.session.questions.map(()=>null);
    state.index=0;
    state.selected=null;
    location.hash="qcm-run";
  };
}
async function renderPlanner(){
 const key="rp-planner-tasks";let tasks=[];try{tasks=JSON.parse(localStorage.getItem(key)||"[]")}catch{}
 view.innerHTML=header("Mon planning de révision","Organise tes révisions avec des objectifs simples. Les tâches sont conservées dans ce navigateur.")+`<div class="panel"><form id="planner-form" class="filters"><div class="field"><label for="task-title">À réviser</label><input id="task-title" required maxlength="100" placeholder="Ex. : fonctions en mathématiques"></div><div class="field"><label for="task-date">Date prévue</label><input id="task-date" type="date" required></div><div class="field"><label for="task-minutes">Durée</label><select id="task-minutes"><option value="15">15 minutes</option><option value="25" selected>25 minutes</option><option value="45">45 minutes</option><option value="60">1 heure</option></select></div><button class="btn primary" style="align-self:end">Ajouter</button></form><p class="tiny">Conseil : prévois des sessions courtes et des pauses. Le planning ne se synchronise pas entre appareils.</p></div><section class="section"><div class="head"><h2>Mes sessions prévues</h2><button id="clear-done" class="btn outline">Supprimer les tâches terminées</button></div><div id="planner-list"></div></section>`;
 const draw=()=>{const list=$("#planner-list");list.innerHTML=tasks.length?tasks.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(t=>`<article class="panel activity"><input type="checkbox" data-task-done="${safe(t.id)}" ${t.done?"checked":""} aria-label="Marquer comme terminé"><div style="flex:1"><b style="${t.done?"text-decoration:line-through;opacity:.65":""}">${safe(t.title)}</b><div class="tiny">${safe(t.date)} · ${t.minutes} min</div></div><button class="btn outline" data-task-delete="${safe(t.id)}">Supprimer</button></article>`).join(""):'<div class="empty">Aucune session planifiée. Ajoute ta première révision ci-dessus.</div>';$$('[data-task-done]').forEach(el=>el.onchange=()=>{const t=tasks.find(x=>x.id===el.dataset.taskDone);if(t)t.done=el.checked;save();draw()});$$('[data-task-delete]').forEach(el=>el.onclick=()=>{tasks=tasks.filter(t=>t.id!==el.dataset.taskDelete);save();draw()});};
 const save=()=>localStorage.setItem(key,JSON.stringify(tasks));$("#planner-form").onsubmit=e=>{e.preventDefault();tasks.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),title:$("#task-title").value.trim(),date:$("#task-date").value,minutes:Number($("#task-minutes").value),done:false});save();e.target.reset();$("#task-minutes").value="25";draw();toast("Session ajoutée au planning.")};$("#clear-done").onclick=()=>{tasks=tasks.filter(t=>!t.done);save();draw()};draw();
}
async function renderControles(){return renderWrittenAssessment("controle")}
async function renderExams(){return renderWrittenAssessment("examen")}
async function renderWrittenAssessment(mode){
 const isExam=mode==="examen";
 const title=isExam?"Examens blancs":"Contrôles par chapitre";
 const description=isExam?"Compose une épreuve écrite avec plusieurs exercices, des réponses rédigées et un temps limité. Aucun QCM n'est utilisé ici.":"Choisis une matière et un chapitre, puis réponds à des questions ouvertes comme lors d'un contrôle en classe.";
 view.innerHTML=header(title,description)+`<div class="panel"><div class="filters">${levelControl()}${subjectControl(localStorage.getItem("rp-written-subject")||"")}<div class="field"><label for="written-duration">DURÉE</label><select id="written-duration"><option value="20">20 minutes</option><option value="30" selected>30 minutes</option><option value="45">45 minutes</option><option value="60">1 heure</option><option value="90">1 h 30</option></select></div><div class="field" id="chapter-field"><label for="written-chapter">CHAPITRE</label><select id="written-chapter"><option value="">Choisir un chapitre</option></select></div></div><p class="tiny">Les réponses sont rédigées librement. La correction est indicative : Réussite+ ne note pas automatiquement une dissertation, une démonstration ou une réponse longue. Les résultats sont conservés dans ce navigateur.</p><div id="written-info" class="lead" aria-live="polite">Chargement des chapitres…</div><div class="actions"><button class="btn primary" id="written-start" disabled>${isExam?"Commencer l'examen blanc":"Commencer le contrôle"} →</button><a class="btn outline" href="#cours">Revoir les cours</a></div></div><section id="written-area" class="section"></section>`;
 bindLevel();
 const subjectEl=$("#subject-select"),chapterEl=$("#written-chapter"),durationEl=$("#written-duration"),startEl=$("#written-start"),chapterField=$("#chapter-field");
 if(isExam)chapterField.style.display="none";
 let courses=[];
 const getCourseData=async()=>{courses=[];const id=subjectEl.value;if(!id)return;const subjects=(state.subjects[state.level]||[]).filter(x=>x.id===id);for(const sub of subjects){try{const rows=await load(`data/courses/${state.level}/${sub.id}.json`);courses.push(...rows.map(c=>({...c,_subject:sub.name,_subjectId:sub.id})));}catch(e){console.warn("Cours indisponible",sub.id,e)}}};
 const refresh=async()=>{startEl.disabled=true;$("#written-area").innerHTML="";await getCourseData();const chapters=[...new Set(courses.map(c=>c.chapitre).filter(Boolean))];chapterEl.innerHTML='<option value="">Choisir un chapitre</option>'+chapters.map(c=>`<option value="${safe(c)}">${safe(c)}</option>`).join("");$("#written-info").textContent=!subjectEl.value?"Choisis une matière pour charger les sujets écrits.":courses.length?`${courses.length} fiche(s) de cours chargée(s), ${chapters.length} chapitre(s) disponible(s).`:"Aucune fiche disponible pour cette sélection.";startEl.disabled=!subjectEl.value||(isExam?!courses.length:!chapters.length);if(!isExam&&chapters.length)chapterEl.value=chapters[0];};
 subjectEl.onchange=()=>{localStorage.setItem("rp-written-subject",subjectEl.value);refresh()};
 chapterEl.onchange=()=>{startEl.disabled=!chapterEl.value};
 const buildTasks=(selectedCourses)=>{
   const tasks=[];
   selectedCourses.forEach(c=>{
     const defs=(c.definitions||[]).filter(d=>d.terme&&d.definition);
     const methods=(c.methode_etapes||[]).filter(Boolean);
     const examples=(c.exemples_resolus||[]).filter(Boolean);
     const exercise=(c.exercices||[]).find(x=>x.question);
     if(defs.length){const d=defs[0];tasks.push({chapter:c.chapitre,title:"Question de cours",prompt:`Définis précisément « ${d.terme} », explique cette notion avec tes propres mots, puis donne un exemple personnel.`,guide:`Éléments attendus : ${d.definition} Une réponse complète doit contenir une définition, une explication et un exemple pertinent.`,points:4,course:c});}
     if(methods.length){tasks.push({chapter:c.chapitre,title:"Méthode et raisonnement",prompt:`Présente une méthode pour traiter un exercice de ce chapitre. Décris les étapes dans l'ordre et explique pourquoi elles sont utiles.`,guide:`Points à vérifier : ${methods.join(" → ")} La réponse doit être organisée et justifier les étapes.`,points:6,course:c});}
     if(examples.length){tasks.push({chapter:c.chapitre,title:"Application",prompt:`Résous ou explique l'exemple suivant en détaillant ton raisonnement : ${examples[0]}`,guide:`Compare ta démarche avec l'exemple du cours : ${examples[0]} Une réponse complète montre les étapes, le résultat et une vérification si elle est pertinente.`,points:6,course:c});}
     if(exercise){tasks.push({chapter:c.chapitre,title:"Exercice rédigé",prompt:exercise.question,guide:exercise.correction||"La correction doit présenter une démarche claire, les étapes utiles et une conclusion.",points:4,course:c});}
   });
   const seen=new Set();return tasks.filter(t=>{const k=t.chapter+"|"+t.title+"|"+t.prompt;if(seen.has(k))return false;seen.add(k);return true});
 };
 startEl.onclick=()=>{
   const selectedCourses=isExam?courses.slice():courses.filter(c=>c.chapitre===chapterEl.value);
   let tasks=buildTasks(selectedCourses);
   if(isExam){tasks.sort(()=>Math.random()-.5);tasks=tasks.slice(0,Math.min(6,tasks.length));}
   else tasks=tasks.slice(0,4);
   if(!tasks.length){$("#written-info").textContent="Aucune question rédigée exploitable dans cette fiche. Il faut enrichir le contenu de ce chapitre avant de proposer un contrôle.";return;}
   clearInterval(state.examTimer);let remaining=Number(durationEl.value)*60;const started=Date.now();const savedKey=`rp-written-draft-${mode}-${state.level}-${subjectEl.value}-${chapterEl.value||"mix"}`;
   const subjectName=subjectEl.value?(subjectById(subjectEl.value)?.name||subjectEl.value):"Toutes les matières";
   const draw=()=>{const old=JSON.parse(localStorage.getItem(savedKey)||"{}");$("#written-area").innerHTML=`<div class="panel"><div class="qtop"><span class="badge">${isExam?"EXAMEN BLANC":"CONTRÔLE"} · ${safe(subjectName)}</span><strong id="written-timer">${Math.floor(remaining/60)}:${String(remaining%60).padStart(2,"0")}</strong></div><p class="lead">${isExam?"Sujet transversal composé de plusieurs exercices écrits.":`Chapitre : ${safe(chapterEl.value)}`}. Réponds avec tes propres mots et détaille ton raisonnement. Tu peux sauvegarder tes réponses avant de rendre ta copie.</p><form id="written-form">${tasks.map((t,i)=>`<article class="question" style="margin:16px 0"><div class="qtop"><span>${safe(t.title)} · ${safe(t.chapter)}</span><span>${t.points} points indicatifs</span></div><h3>${i+1}. ${safe(t.prompt)}</h3><label for="written-answer-${i}">Ta réponse rédigée</label><textarea id="written-answer-${i}" data-written-answer="${i}" rows="6" maxlength="10000" placeholder="Rédige ta réponse ici…">${safe(old[i]||"")}</textarea></article>`).join("")}<div class="actions"><button type="button" class="btn outline" id="save-written">Sauvegarder le brouillon</button><button class="btn primary" type="submit">Rendre ma copie</button></div></form><p class="tiny">La durée est indicative dans cette version. Ne ferme pas cette page avant d'avoir sauvegardé ou rendu ta copie.</p></div>`;
    const saveDraft=()=>{const a={};$$('[data-written-answer]').forEach(el=>a[el.dataset.writtenAnswer]=el.value);localStorage.setItem(savedKey,JSON.stringify(a));return a};
    $$('[data-written-answer]').forEach(el=>el.addEventListener("input",saveDraft));$("#save-written").onclick=()=>{saveDraft();toast("Brouillon sauvegardé sur cet appareil.")};
    $("#written-form").onsubmit=e=>{e.preventDefault();clearInterval(state.examTimer);state.examTimer=null;const answers=saveDraft();localStorage.setItem("rp-written-last",JSON.stringify({mode,level:state.level,subject:subjectName,chapter:isExam?"Examen blanc":chapterEl.value,date:new Date().toISOString(),answers,tasks:tasks.map(t=>({title:t.title,prompt:t.prompt,guide:t.guide,points:t.points,chapter:t.chapter}))}));
      $("#written-area").innerHTML=`<div class="panel score"><div class="eyebrow">COPIE REMISE</div><h2>Ton travail est enregistré.</h2><p class="lead">Les réponses longues ne peuvent pas être notées automatiquement de façon fiable. Utilise les critères et les éléments de correction ci-dessous pour t'autoévaluer, ou fais relire ta copie par un enseignant.</p><div class="actions"><button class="btn outline" id="print-written">Imprimer / enregistrer en PDF</button><button class="btn primary" id="new-written">${isExam?"Nouvel examen blanc":"Nouveau contrôle"}</button></div></div>${tasks.map((t,i)=>`<article class="panel" style="margin-top:14px"><span class="badge">${t.points} points indicatifs · ${safe(t.chapter)}</span><h3>${i+1}. ${safe(t.prompt)}</h3><h4>Ta réponse</h4><p style="white-space:pre-wrap">${safe(answers[i]||"Aucune réponse")}</p><details><summary>Voir les éléments de correction et le barème indicatif</summary><p style="white-space:pre-wrap">${safe(t.guide)}</p><ul><li>50 % : exactitude et compréhension.</li><li>30 % : raisonnement, étapes et justification.</li><li>20 % : clarté, vocabulaire et conclusion.</li></ul><label for="self-score-${i}">Mon autoévaluation (sur ${t.points})</label><input id="self-score-${i}" type="number" min="0" max="${t.points}" step="0.5" value="" placeholder="Note à estimer" /></details></article>`).join("")}<p class="tiny">Ces corrigés proviennent des fiches de cours disponibles. Certains contenus du projet restent génériques et doivent être enrichis/validés avant de présenter ces sujets comme des examens officiels.</p>`;
      $("#print-written").onclick=()=>window.print();$("#new-written").onclick=()=>{location.hash=isExam?"examens":"controles"};
    };
   };
   draw();state.examTimer=setInterval(()=>{remaining--;const el=$("#written-timer");if(el)el.textContent=`${Math.floor(Math.max(0,remaining)/60)}:${String(Math.max(0,remaining)%60).padStart(2,"0")}`;if(remaining<=0){clearInterval(state.examTimer);state.examTimer=null;const form=$("#written-form");if(form)form.requestSubmit();}},1000);
 };
 await refresh();
}

async function renderTF(){let qs=[];try{qs=await load("data/true-false/questions.json")}catch{}qs=qs.filter(q=>q.niveau===state.level);view.innerHTML=header("Vrai ou faux","Lis l'affirmation, choisis Vrai ou Faux, puis consulte l'explication.")+`<div class="filters">${levelControl()}${subjectControl()}</div><div id="tf-card" class="question"></div>`;bindLevel();let idx=0,score=0,done=false,filtered=qs;const draw=()=>{const q=filtered[idx];if(!q){$("#tf-card").innerHTML=`<div class="score"><h2>Terminé !</h2><strong>${score}/${filtered.length}</strong><p>Bonnes réponses</p><button id="tf-replay" class="btn primary">Rejouer</button></div>`;$("#tf-replay").onclick=()=>{idx=0;score=0;draw()};return}done=false;$("#tf-card").innerHTML=`<div class="qtop"><span>${safe(q.matiere)} · ${safe(q.chapitre)}</span><span>${idx+1}/${filtered.length}</span></div><h2>${safe(q.statement)}</h2><div class="tf"><button class="btn primary" data-answer="true">Vrai</button><button class="btn outline" data-answer="false">Faux</button></div><div id="tf-feedback"></div>`;$$("[data-answer]").forEach(b=>b.onclick=()=>{if(done)return;done=true;const ok=(b.dataset.answer==="true")===q.answer;if(ok)score++;$("#tf-feedback").innerHTML=`<div class="feedback ${ok?"good":"bad"}">${ok?"Bonne réponse !":"À revoir."} ${q.answer?"La bonne réponse est Vrai.":"La bonne réponse est Faux."}<br>${safe(q.explanation)}</div><button class="btn primary" id="tf-next">Suivant →</button>`;$("#tf-next").onclick=()=>{idx++;draw()}})};const refresh=()=>{const sid=$("#subject-select").value;filtered=qs.filter(q=>(!sid||q.matiere===sid));idx=0;score=0;draw()};$("#subject-select").onchange=refresh;draw()}
async function renderGames(){let cards=[];try{cards=await load("data/games/memory-cards.json")}catch{}view.innerHTML=header("Mini-jeux pédagogiques","Entraîne ta mémoire, ton vocabulaire et tes réflexes avec des activités courtes.")+`<div class="grid"><article class="card game"><span class="badge">60 secondes</span><h3>Défi chrono</h3><p>Réponds au maximum de questions avant la fin du compte à rebours.</p><button class="btn primary" id="timed">Lancer le défi</button></article><article class="card game"><span class="badge">Mémoire</span><h3>Cartes mémoire</h3><p>Lis le recto, essaie de répondre, puis retourne la carte pour vérifier.</p><button class="btn primary" id="memory-start">Jouer aux cartes</button></article><article class="card game"><span class="badge">Calcul mental</span><h3>Calcul express</h3><p>Enchaîne des calculs simples générés à chaque partie.</p><button class="btn primary" id="math-game">Commencer</button></article><article class="card game"><span class="badge">Entraînement</span><h3>Réviser mes erreurs</h3><p>Reprends les questions ratées lors de tes QCM précédents.</p><button class="btn primary" id="mistakes">Revoir mes erreurs</button></article><article class="card game"><span class="badge">Vrai ou faux</span><h3>Défi d'affirmations</h3><p>Vérifie rapidement tes connaissances et lis les corrections.</p><a class="btn primary" href="#vrai-faux">Jouer</a></article><article class="card game"><span class="badge">Culture</span><h3>Défi culture générale</h3><p>Teste tes connaissances sur les sciences, l'histoire et la géographie.</p><a class="btn primary" href="#culture">Jouer</a></article></div><section id="game-area" class="section"></section>`;$("#timed").onclick=()=>startTimed();$("#memory-start").onclick=()=>startMemory(cards);$("#math-game").onclick=()=>startMental();$("#mistakes").onclick=()=>startMistakes()}
async function startTimed(){let qs=[];for(const s of state.subjects[state.level]||[]){try{qs.push(...await load(`data/qcm/${state.level}/${s.id}.json`))}catch{}}qs.sort(()=>Math.random()-.5);let idx=0,score=0,secs=60,cur=null,answered=false;const area=$("#game-area");area.innerHTML=`<div class="question"><div class="qtop"><b>Défi chrono</b><b id="timer">60 s</b></div><h2 id="timed-question"></h2><div class="options" id="timed-options"></div><div id="timed-feedback"></div><p>Score : <b id="timed-score">0</b></p><button class="btn primary" id="timed-next">Commencer</button></div>`;const next=()=>{if(secs<=0){area.querySelector(".question").innerHTML=`<div class="score"><h2>Temps écoulé !</h2><strong>${score} point(s)</strong><button id="again" class="btn primary">Rejouer</button></div>`;$("#again").onclick=startTimed;return}cur=qs[idx++%qs.length];answered=false;$("#timed-question").textContent=cur.question;$("#timed-options").innerHTML=cur.options.map((o,i)=>`<button class="option" data-i="${i}">${safe(o)}</button>`).join("");$("#timed-feedback").textContent="";$("#timed-score").textContent=score;$$("[data-i]",area).forEach(b=>b.onclick=()=>{if(answered||secs<=0)return;answered=true;const ok=+b.dataset.i===cur.correctIndex;if(ok)score++;$("#timed-feedback").innerHTML=`<div class="feedback ${ok?"good":"bad"}">${ok?"Correct !":"À revoir : "+safe(cur.options[cur.correctIndex])}<br>${safe(cur.explanation)}</div>`;$("#timed-score").textContent=score})};$("#timed-next").onclick=next;next();state.gameTimer=setInterval(()=>{secs--;$("#timer")&&($("#timer").textContent=secs+" s");if(secs<=0){clearInterval(state.gameTimer);state.gameTimer=null;next()}},1000)}
function startMental(){let n=0,score=0,a,b,op,answer;const area=$("#game-area");const next=()=>{a=2+Math.floor(Math.random()*18);b=2+Math.floor(Math.random()*12);op=Math.random()>.5?"+":"×";answer=op==="+"?a+b:a*b;area.innerHTML=`<div class="question"><div class="qtop"><span>Calcul mental</span><span>${n} réponse(s) · score ${score}</span></div><h2>${a} ${op} ${b} = ?</h2><form id="mental-form" class="filters"><div class="field"><label for="mental-answer">TA RÉPONSE</label><input id="mental-answer" type="number" required inputmode="numeric"></div><button class="btn primary" style="align-self:end">Valider</button></form><p id="mental-feedback" aria-live="polite"></p></div>`;$("#mental-form").onsubmit=e=>{e.preventDefault();const val=+$("#mental-answer").value;const ok=val===answer;if(ok)score++;n++;$("#mental-feedback").innerHTML=`<div class="feedback ${ok?"good":"bad"}">${ok?"Exact !":`La réponse était ${answer}.`}</div><button class="btn primary" id="mental-next">Question suivante</button>`;$("#mental-next").onclick=next}};next()}
function startMemory(cards){let i=0,back=false;const area=$("#game-area");const draw=()=>{if(!cards.length){area.innerHTML='<div class="empty">Aucune carte disponible.</div>';return}const c=cards[i%cards.length];area.innerHTML=`<div class="panel"><div class="qtop"><span>Carte mémoire</span><span>${i+1}/${cards.length}</span></div><button class="memory" id="flip">${safe(back?c.back:c.front)}</button><p>Appuie sur la carte pour ${back?"revoir la question":"afficher la réponse"}.</p><div class="actions"><button id="mem-prev" class="btn outline">← Précédente</button><button id="mem-next" class="btn primary">Suivante →</button></div></div>`;$("#flip").onclick=()=>{back=!back;draw()};$("#mem-prev").onclick=()=>{i=(i-1+cards.length)%cards.length;back=false;draw()};$("#mem-next").onclick=()=>{i=(i+1)%cards.length;back=false;draw()}};draw()}
async function startMistakes(){const wrong=[...new Set(state.results.flatMap(r=>r.wrongIds||[]))];if(!wrong.length){$("#game-area").innerHTML='<div class="empty">Aucune erreur enregistrée pour le moment. Fais un QCM puis reviens ici.</div>';return}let qs=[];for(const l of Object.keys(levelNames))for(const s of state.subjects[l]||[]){try{qs.push(...(await load(`data/qcm/${l}/${s.id}.json`)).filter(q=>wrong.includes(q.id)))}catch{}}if(!qs.length){$("#game-area").innerHTML='<div class="empty">Les questions ratées ne sont plus disponibles dans les banques chargées.</div>';return}state.session={questions:qs,subject:"Erreurs à revoir",level:state.level,kind:"review"};state.answers=qs.map(()=>null);state.index=0;state.selected=null;location.hash="qcm-run"}
function renderCulture(){view.innerHTML=header("Culture générale","Questions courtes avec explications pour explorer les sciences, l'histoire, la géographie, la littérature et les technologies.")+`<div class="panel"><div class="filters"><div class="field"><label for="cg-category">CATÉGORIE</label><select id="cg-category"><option value="">Toutes les catégories</option></select></div><div class="field"><label for="cg-diff">DIFFICULTÉ</label><select id="cg-diff"><option value="">Toutes</option><option>facile</option><option>intermediaire</option><option>difficile</option></select></div></div><div id="cg-area"></div></div>`;load("data/culture-generale/questions.json").then(qs=>{const cats=[...new Set(qs.map(q=>q.category))];$("#cg-category").innerHTML='<option value="">Toutes les catégories</option>'+cats.map(c=>`<option>${safe(c)}</option>`).join("");let filtered=qs,idx=0,score=0,done=false;const draw=()=>{const q=filtered[idx];if(!q){$("#cg-area").innerHTML=`<div class="score"><h2>Défi terminé</h2><strong>${score}/${filtered.length}</strong><p>Bonne(s) réponse(s)</p><button id="cg-replay" class="btn primary">Rejouer</button></div>`;$("#cg-replay").onclick=()=>{idx=0;score=0;draw()};return}done=false;$("#cg-area").innerHTML=`<div class="qtop"><span>${safe(q.category)} · ${safe(q.difficulty)}</span><span>${idx+1}/${filtered.length}</span></div><h2>${safe(q.question)}</h2><div class="options">${q.options.map((o,i)=>`<button class="option" data-cg="${i}">${safe(o)}</button>`).join("")}</div><div id="cg-feedback"></div>`;$$("[data-cg]").forEach(b=>b.onclick=()=>{if(done)return;done=true;const ok=+b.dataset.cg===q.correctIndex;if(ok)score++;$("#cg-feedback").innerHTML=`<div class="feedback ${ok?"good":"bad"}">${ok?"Bonne réponse !":"La bonne réponse était : "+safe(q.options[q.correctIndex])}<br>${safe(q.explanation)}</div><button class="btn primary" id="cg-next">Suivant →</button>`;$("#cg-next").onclick=()=>{idx++;draw()}})};const filter=()=>{filtered=qs.filter(q=>(!$("#cg-category").value||q.category===$("#cg-category").value)&&(!$("#cg-diff").value||q.difficulty===$("#cg-diff").value));idx=0;score=0;draw()};$("#cg-category").onchange=filter;$("#cg-diff").onchange=filter;filter()}).catch(()=>$("#cg-area").innerHTML='<div class="empty">Impossible de charger les questions de culture générale.</div>')}
function renderDashboard(){const s=stats(),by={};state.results.forEach(r=>{by[r.subject]??={score:0,total:0};by[r.subject].score+=r.score;by[r.subject].total+=r.total});view.innerHTML=header("Ma progression","Tes statistiques sont calculées à partir des résultats enregistrés sur cet appareil. Aucun chiffre n'est inventé.")+`<div class="statgrid"><div class="card stat"><span>Questions répondues</span><strong>${s.total}</strong></div><div class="card stat"><span>Bonnes réponses</span><strong>${s.correct}</strong></div><div class="card stat"><span>Taux de réussite</span><strong>${s.pct}%</strong></div><div class="card stat"><span>Tentatives</span><strong>${state.results.length}</strong></div></div><section class="section columns"><div class="panel"><h2>Résultats par matière</h2>${Object.entries(by).length?Object.entries(by).map(([k,v])=>`<div class="activity"><span style="flex:1">${safe(k)}</span><b>${Math.round(v.score/v.total*100)}%</b><span class="tiny">${v.score}/${v.total}</span></div>`).join(""):'<div class="empty">Fais un QCM pour voir tes résultats ici.</div>'}</div><div class="panel"><h2>Objectif de la semaine</h2><p class="lead">Choisis un objectif personnel et coche-le lorsque tu l'as atteint.</p><label><input id="goal" type="checkbox" ${localStorage.getItem("rp-goal")==="true"?"checked":""}> J'ai fait 3 sessions de révision cette semaine</label><div class="actions"><a class="btn primary" href="#qcm">Reprendre mes révisions</a><a class="btn outline" href="#favoris">Mes favoris</a></div></div></section><section class="section panel"><h2>Historique des QCM</h2>${state.recent.length?state.recent.map(r=>`<div class="activity"><span class="badge">${safe(r.level)}</span><span style="flex:1">${safe(r.subject)}</span><span class="tiny">${safe(r.date)}</span><b>${r.score}/${r.total}</b></div>`).join(""):'<div class="empty">Aucun résultat enregistré.</div>'}<div class="actions"><button id="reset-progress" class="btn outline">Réinitialiser ma progression locale</button></div></section>`;$("#goal").onchange=e=>localStorage.setItem("rp-goal",String(e.target.checked));$("#reset-progress").onclick=()=>{if(confirm("Effacer les résultats et favoris enregistrés sur cet appareil ?")){state.results=[];state.recent=[];state.favorites=[];localStorage.removeItem("rp-results");localStorage.removeItem("rp-recent");localStorage.removeItem("rp-favorites");renderDashboard();toast("Données locales effacées.")}}}
async function renderErrorNotebook(){
  const wrongIds=[...new Set(state.results.flatMap(r=>r.wrongIds||[]))];
  view.innerHTML=header("Mon carnet d’erreurs","Retrouve les questions ratées, relis les corrections et entraîne-toi à nouveau.")+`<div class="panel"><p class="lead" id="error-summary">Recherche des questions à revoir…</p><div class="actions"><button id="review-all-errors" class="btn primary" disabled>Réviser toutes mes erreurs</button><a class="btn outline" href="#qcm">Faire un nouveau QCM</a></div></div><section class="section" id="error-list"></section>`;
  if(!wrongIds.length){$("#error-summary").textContent="Ton carnet est vide pour le moment. Après un QCM, les questions ratées apparaîtront ici automatiquement.";$("#error-list").innerHTML='<div class="empty">Aucune erreur enregistrée pour le moment. Continue comme ça !</div>';return;}
  const found=[];
  for(const level of Object.keys(levelNames)){
    for(const subject of state.subjects[level]||[]){
      try{const qs=await load(`data/qcm/${level}/${subject.id}.json`);for(const q of qs)if(wrongIds.includes(q.id))found.push({...q,_level:level,_subject:subject.name});}catch{}
    }
  }
  const unique=[...new Map(found.map(q=>[q.id,q])).values()];
  $("#error-summary").textContent=`${unique.length} question(s) différente(s) à revoir. Les erreurs sont enregistrées uniquement dans ce navigateur.`;
  $("#review-all-errors").disabled=!unique.length;
  $("#review-all-errors").onclick=()=>{
    if(!unique.length)return;
    state.session={questions:unique,subject:"Carnet d’erreurs",level:state.level,started:Date.now(),kind:"review"};
    state.answers=unique.map(()=>null);state.index=0;state.selected=null;location.hash="qcm-run";
  };
  $("#error-list").innerHTML=unique.length?unique.map(q=>{const ci=getCorrectIndex(q);return `<article class="panel error-entry"><div class="qtop"><span class="badge">${safe(levelNames[q._level])} · ${safe(q._subject)}</span><span>${safe(q.chapitre||"À revoir")}</span></div><h3>${safe(q.question)}</h3><p><b>Bonne réponse :</b> ${safe(q.options?.[ci]??"Correction indisponible")}</p><p>${safe(getExplanation(q)||"Aucune explication disponible pour cette question.")}</p><button class="btn outline" data-review-one="${safe(q.id)}">Réviser cette question</button></article>`}).join(""):'<div class="empty">Les questions ratées ne sont plus présentes dans les banques actuelles.</div>';
  $$('[data-review-one]').forEach(button=>button.onclick=()=>{const q=unique.find(item=>item.id===button.dataset.reviewOne);if(!q)return;state.session={questions:[q],subject:"Erreur à revoir",level:q._level,started:Date.now(),kind:"review"};state.answers=[null];state.index=0;state.selected=null;location.hash="qcm-run";});
}

async function renderFavorites(){let qs=[];for(const l of Object.keys(levelNames))for(const s of state.subjects[l]||[]){try{qs.push(...await load(`data/qcm/${l}/${s.id}.json`))}catch{}}const fav=qs.filter(q=>state.favorites.includes(q.id));view.innerHTML=header("Mes favoris","Les questions marquées d'une étoile sont conservées dans ce navigateur.")+(fav.length?`<div class="course-list">${fav.map(q=>`<article class="card course"><span class="badge">${safe(q.niveau)} · ${safe(q.matiere)}</span><h3>${safe(q.question)}</h3><p>${safe(q.chapitre)}</p><p class="tiny">${safe(q.explanation)}</p><button class="btn outline" data-unfav="${safe(q.id)}">Retirer des favoris</button></article>`).join("")}</div>`:`<div class="empty">Tu n'as pas encore de favoris.<b>Ajoute des questions pendant un QCM.</b><a class="btn primary" href="#qcm">Faire un QCM</a></div>`);$$("[data-unfav]").forEach(b=>b.onclick=()=>{state.favorites=state.favorites.filter(id=>id!==b.dataset.unfav);localStorage.setItem("rp-favorites",JSON.stringify(state.favorites));renderFavorites()})}


async function syncProgressToCloud() {
  const client = await getSupabaseClient();
  const { data: sessionData, error: sessionError } = await client.auth.getSession();
  if (sessionError) throw sessionError;
  const user = sessionData?.session?.user;
  if (!user) throw new Error("Connecte-toi d’abord pour synchroniser ta progression.");

  const readJSON = (key, fallback) => {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
    catch { return fallback; }
  };
  const localProgress = {
    results: readJSON("rp-results", []),
    favorites: readJSON("rp-favorites", []),
    recent: readJSON("rp-recent", []),
    level: localStorage.getItem("rp-level") || state.level,
    nickname: localStorage.getItem("rp-nickname") || "Élève",
    goal: localStorage.getItem("rp-goal") || "false",
    theme: localStorage.getItem("rp-theme") || "light"
  };
  const { data: existing, error: readError } = await client
    .from("user_progress").select("progress").eq("user_id", user.id).maybeSingle();
  if (readError) throw readError;
  const cloud = existing?.progress || {};
  const keyResult = r => `${r.date||""}|${r.level||""}|${r.subject||""}|${r.score||0}|${r.total||0}|${r.kind||"qcm"}`;
  const results = [...new Map([...(cloud.results||[]), ...localProgress.results].map(r => [keyResult(r),r])).values()].slice(-1000);
  const favorites = [...new Set([...(cloud.favorites||[]), ...localProgress.favorites])];
  const recent = [...new Map([...(cloud.recent||[]), ...localProgress.recent].map(r => [keyResult(r),r])).values()].slice(-20).reverse();
  const progress = {
    ...cloud, ...localProgress, results, favorites, recent,
    updatedAt: new Date().toISOString()
  };
  const { error: saveError } = await client.from("user_progress").upsert({
    user_id: user.id, progress, updated_at: progress.updatedAt
  }, { onConflict: "user_id" });
  if (saveError) throw saveError;
  localStorage.setItem("rp-results", JSON.stringify(results));
  localStorage.setItem("rp-favorites", JSON.stringify(favorites));
  localStorage.setItem("rp-recent", JSON.stringify(recent));
  state.results = results; state.favorites = favorites; state.recent = recent;
  return `Progression synchronisée : ${results.length} résultats et ${favorites.length} favoris.`;
}

function renderProfile() {
  view.innerHTML = header(
    "Profil & préférences",
    "Crée ton compte Réussite+ ou connecte-toi."
  ) + `
    <div class="panel">
      <h2>Compte Réussite+</h2>

      <div class="field">
        <label for="auth-mode">ACTION</label>
        <select id="auth-mode">
          <option value="register">Créer un compte</option>
          <option value="login">Se connecter</option>
        </select>
      </div>

      <div class="field" id="username-field">
        <label for="auth-username">PSEUDO (3 à 20 caractères)</label>
        <input id="auth-username" maxlength="20" placeholder="Ton pseudo">
      </div>

      <div class="field">
        <label for="auth-email">E-MAIL</label>
        <input id="auth-email" type="email" maxlength="254"
          autocomplete="email" placeholder="toi@exemple.com">
      </div>

      <div class="field">
        <label for="auth-password">MOT DE PASSE</label>
        <input id="auth-password" type="password" minlength="8"
          maxlength="128" autocomplete="current-password"
          placeholder="8 caractères minimum">
      </div>

      <button class="btn primary" id="auth-submit">Créer mon compte</button>
      <p id="auth-message" role="status" aria-live="polite"></p>

      <hr>
      <h3>Profil local</h3>
      <div class="filters">
        ${levelControl()}
        <div class="field">
          <label for="nickname">PSEUDO LOCAL</label>
          <input id="nickname" maxlength="30"
            value="${safe(localStorage.getItem("rp-nickname") || "Élève")}">
        </div>
      </div>
      <button class="btn" id="save-profile">Enregistrer les préférences</button>
      <hr>
      <h3>Progression cloud</h3>
      <p class="tiny">La synchronisation est déclenchée uniquement quand tu appuies sur ce bouton.</p>
      <button class="btn outline" id="sync-progress">Synchroniser ma progression</button>
      <p id="sync-message" role="status" aria-live="polite"></p>
    </div>
  `;

  bindLevel();

  const mode = $("#auth-mode");
  const usernameField = $("#username-field");
  const submit = $("#auth-submit");
  const message = $("#auth-message");

  function updateMode() {
    const registering = mode.value === "register";
    usernameField.hidden = !registering;
    submit.textContent = registering ? "Créer mon compte" : "Se connecter";
    $("#auth-password").autocomplete = registering
      ? "new-password"
      : "current-password";
    message.textContent = "";
  }

  mode.addEventListener("change", updateMode);
  updateMode();

  submit.onclick = async () => {
    const registering = mode.value === "register";
    const username = $("#auth-username").value.trim();
    const email = $("#auth-email").value.trim();
    const password = $("#auth-password").value;

    if (!email || !password || (registering && !/^[a-zA-Z0-9_-]{3,20}$/.test(username))) {
      message.textContent = registering
        ? "Vérifie ton e-mail, ton mot de passe et ton pseudo."
        : "Entre ton e-mail et ton mot de passe.";
      return;
    }

    submit.disabled = true;
    message.textContent = "Patiente un instant…";

    try {
      const response = await fetch(
        `/.netlify/functions/${registering ? "register" : "login"}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(
            registering
              ? { username, email, password }
              : { email, password }
          )
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Une erreur est survenue.");
      }

      if (!registering && result.user) {
        // Le serveur valide le mot de passe ; on installe ensuite la session
        // renvoyée par Supabase dans le client pour conserver l'état connecté.
        if (result.session?.access_token && result.session?.refresh_token) {
          const client = await getSupabaseClient();
          const { error: sessionError } = await client.auth.setSession({
            access_token: result.session.access_token,
            refresh_token: result.session.refresh_token
          });
          if (sessionError) throw sessionError;
        }
        localStorage.setItem("rp-nickname", result.user.email.split("@")[0]);
        $("#profile").textContent = localStorage.getItem("rp-nickname");
      }
      message.textContent = result.message || "Connexion réussie.";
    } catch (error) {
      message.textContent =
        error.message || "Impossible de contacter le serveur.";
    } finally {
      submit.disabled = false;
    }
  };

  $("#save-profile").onclick = () => {
    localStorage.setItem(
      "rp-nickname",
      $("#nickname").value.trim() || "Élève"
    );
    toast("Préférences enregistrées sur cet appareil.");
    $("#profile").textContent =
      localStorage.getItem("rp-nickname") || "Mode invité";
  };

  const syncButton = $("#sync-progress");
  const syncMessage = $("#sync-message");
  syncButton.onclick = async () => {
    syncButton.disabled = true;
    syncMessage.textContent = "Synchronisation en cours…";
    try {
      syncMessage.textContent = await syncProgressToCloud();
      toast("Progression synchronisée.");
    } catch (error) {
      syncMessage.textContent = error.message || "La synchronisation a échoué.";
    } finally {
      syncButton.disabled = false;
    }
  };
}

function renderPrivacy(){view.innerHTML=header("Confidentialité","Informations sur les données utilisées par cette version du site.")+`<div class="panel"><h2>Mode invité</h2><p>Le niveau choisi, le pseudo local, les favoris, les résultats et certaines préférences sont stockés dans le LocalStorage du navigateur. Ces données ne sont pas envoyées à un serveur par le code de cette version.</p><h2>Mineurs et publication</h2><p>Avant toute publication publique, le responsable du site doit vérifier les obligations applicables aux mineurs, les règles de protection des données, l'information des utilisateurs, les éventuels traceurs et les conditions du fournisseur d'authentification. Cette page n'est pas un avis juridique.</p><h2>Supprimer les données</h2><p>Utilise « Réinitialiser ma progression locale » depuis le tableau de bord, ou efface les données du site dans les paramètres du navigateur.</p><h2>Limites</h2><p>Le compte Supabase permet l’inscription et la connexion si les variables Netlify et le schéma SQL sont configurés. La progression reste locale par défaut ; elle n’est envoyée à Supabase que si l’utilisateur connecté choisit explicitement « Synchroniser ma progression ». Aucune récupération de mot de passe n’est implémentée. Les contenus pédagogiques doivent être comparés au cours de classe et aux programmes en vigueur.</p></div>`}
$("#theme").onclick=()=>{const dark=document.documentElement.dataset.theme!=="dark";document.documentElement.dataset.theme=dark?"dark":"light";localStorage.setItem("rp-theme",dark?"dark":"light");$("#theme").textContent=dark?"☀":"☾"};$("#mobile-menu").onclick=()=>$("#nav").classList.toggle("open");$("#profile").onclick=()=>location.hash="profil";$("#nav").addEventListener("click",e=>{if(e.target.closest("a"))$("#nav").classList.remove("open")});window.addEventListener("hashchange",route);

async function init() {
  if (localStorage.getItem("rp-theme") === "dark") {
    document.documentElement.dataset.theme = "dark";
  }

  $("#theme").textContent =
    document.documentElement.dataset.theme === "dark" ? "☀" : "☾";

  $("#profile").textContent =
    localStorage.getItem("rp-nickname") || "Mode invité";

  try {
    
    await loadLevel();
    route();
  } catch (e) {
    view.innerHTML = `<div class="empty">
      <b>Impossible de charger les données du site.</b>
      <p>${safe(e.message)}</p>
    </div>`;
  }
}




async function getSupabaseClient() {
  if (supabaseClient) return supabaseClient;

  const response = await fetch("/.netlify/functions/config");
  if (!response.ok) {
    throw new Error("Configuration Supabase indisponible.");
  }

  const config = await response.json();
  if (!window.supabase?.createClient) throw new Error("Bibliothèque Supabase indisponible.");
  supabaseClient = window.supabase.createClient(config.url, config.anonKey);

  return supabaseClient;
}

init();
