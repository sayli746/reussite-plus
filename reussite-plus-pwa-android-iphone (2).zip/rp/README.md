# Réussite+ — dossier de travail final

**Slogan :** « Révise aujourd'hui, réussis demain. »

Application web statique de révision pour les niveaux **3e, seconde, première et terminale**, avec QCM, fiches de révision, mini-jeux, culture générale, progression locale, carnet d’erreurs, favoris, compte Supabase optionnel et synchronisation cloud déclenchée manuellement.

## Contenu de cette archive

- `index.html`, `app.js`, `styles.css` : interface et logique de l’application.
- Pages ajoutées/renforcées : examens blancs chronométrés (banques QCM existantes), planning local de révision, corrections avec réponse correcte, liens directs depuis le menu et le tableau de bord.
- SEO de base : métadonnées, canonical, `robots.txt` et `sitemap.xml`.
- Le site a des styles responsives et un menu mobile ; il reste nécessaire de tester manuellement sur plusieurs tailles d’écran.
- `data/subjects.json` : matières et niveaux disponibles.
- `data/qcm/` : 48 banques, chacune contenant 100 questions, soit **4 800 questions**.
- `data/courses/` : **240 fiches** au total, soit cinq fiches par matière et niveau (une fiche d’origine et quatre fiches structurées ajoutées).
- `data/true-false/`, `data/games/`, `data/culture-generale/` : activités complémentaires.
- `data/supabase-schema.sql` : tables et politiques de sécurité Supabase.
- `netlify/functions/` : fonctions serveur pour l’inscription, la connexion et la configuration Supabase.
- `scripts/validate-data.js` et `tests/smoke-test.js` : contrôles de structure et tests automatiques.
- `data/inventory.json` et `data/content-audit.json` : inventaire et bilan de contenu.
- `FINAL_STATUS.md` et `AUDIT_FINAL.md` : bilan et limites connues.
- `DEPLOYMENT_CHECKLIST.md` : étapes de déploiement et tests manuels à faire.

## Lancer et tester le projet

1. Décompresse le ZIP.
2. Lance un serveur HTTP statique depuis le dossier du projet, ou déploie le dossier sur Netlify. Ouvrir `index.html` directement en `file://` peut empêcher le chargement des fichiers JSON.
3. Pour tester les données, installe Node.js puis exécute :

```bash
node scripts/validate-data.js
node tests/smoke-test.js
node --check app.js
node --check netlify/functions/login.js
node --check netlify/functions/register.js
node --check netlify/functions/config.js
```

Le validateur vérifie les champs requis, les identifiants, les énoncés identiques au sein d’une banque, les propositions de réponse et les décomptes. Ces contrôles automatiques ne remplacent pas une relecture disciplinaire des contenus.

## Déploiement Netlify

- Le fichier `netlify.toml` publie le dossier du projet et déclare `netlify/functions` comme répertoire des fonctions.
- Déploie le dossier complet, avec `index.html`, `app.js`, `styles.css`, `data/` et `netlify/functions/`.
- Configure dans Netlify les variables `SUPABASE_URL`, `SUPABASE_ANON_KEY` et `SUPABASE_SERVICE_ROLE_KEY`.
- **La clé `SUPABASE_SERVICE_ROLE_KEY` doit rester côté serveur uniquement.** Ne la place jamais dans `app.js`, `index.html`, un fichier public ou une capture d’écran.
- L’URL publique Supabase et la clé anon sont prévues pour le client, mais les politiques RLS doivent rester activées et correctement configurées.

## Configuration Supabase

1. Dans Supabase SQL Editor, exécute `data/supabase-schema.sql`.
2. Configure les URL de redirection d’authentification et les e-mails de confirmation selon ton domaine Netlify.
3. Vérifie les variables d’environnement dans Netlify et redéploie.
4. Teste l’inscription, la confirmation e-mail, la connexion et la synchronisation depuis le site publié.

La progression reste locale par défaut. Dans la page Profil, l’utilisateur connecté peut choisir **« Synchroniser ma progression »** pour envoyer ses résultats, ses favoris et son historique à la table `user_progress`. La synchronisation n’a pas été testée sur le vrai compte Supabase dans cet environnement : elle doit être validée après configuration.

## Contenus pédagogiques : lecture indispensable

Les programmes de référence sont publiés par le ministère et Éduscol :
- [Programmes du collège](https://www.education.gouv.fr/les-programmes-du-college-470408)
- [Programmes du lycée général et technologique](https://www.education.gouv.fr/reussir-au-lycee/les-programmes-du-lycee-general-et-technologique-9812)
- [Enseigner au cycle 4 — Éduscol](https://eduscol.education.fr/)
- [Enseigner au lycée général/technologique — Éduscol](https://eduscol.education.fr/)

Le projet contient 100 énoncés distincts dans chaque banque. **Attention : l’unicité textuelle ne garantit pas 100 notions distinctes.** Une partie des banques a été complétée avec des vérifications conceptuelles structurées à partir d’un ensemble de notions. Ces questions ont des formulations distinctes, mais certaines réutilisent les mêmes notions sous plusieurs angles ; **3847 questions** portent le champ `reviewStatus: "à relire pédagogiquement"`. Les enseignants ou responsables du projet doivent vérifier les distracteurs, les réponses, le niveau attendu et les quasi-doublons avant de présenter ces banques comme des contenus certifiés.

Les fiches de révision sont plus structurées, mais elles ne prétendent pas couvrir exhaustivement chaque chapitre et chaque spécialité des programmes. Les examens blancs sont générés à partir des banques de QCM, pas à partir de sujets officiels complets. Le planning et la progression restent enregistrés dans le navigateur de l’utilisateur. Elles complètent le cours de classe ; elles ne le remplacent pas.

## Confidentialité et sécurité

- Les résultats, favoris, historique et préférences restent sur l’appareil tant que l’utilisateur ne choisit pas de synchroniser.
- Les fonctions d’inscription et de connexion utilisent les fonctions Netlify et Supabase si les variables sont configurées.
- La progression cloud utilise les politiques RLS de `data/supabase-schema.sql`.
- La récupération de mot de passe n’est pas implémentée dans cette version.
- Avant une publication publique, vérifie les paramètres de sécurité, les e-mails de confirmation, les URL autorisées, les obligations de protection des données et les conditions adaptées aux utilisateurs mineurs.

## Périmètre

- Niveaux : 3e, seconde, première, terminale.
- Aucune section **Orientation** n’est incluse.
- L’archive fournit les fichiers et les tests automatiques ; elle ne prouve pas que le déploiement réel ou la configuration de comptes externes a été exécuté. Consulte `FINAL_STATUS.md` pour les limites et les tests effectués.


## Filtres QCM (version corrigée)

Les filtres de QCM sont reliés à une logique dédiée dans `qcm-filters.js` :
- le changement de niveau recharge les matières et les banques correspondantes ;
- le choix d’une matière limite les chapitres disponibles ;
- le choix de la difficulté actualise les chapitres et leur nombre de questions ;
- le choix du chapitre et de la difficulté filtre effectivement les questions avant le lancement ;
- le compteur, les volumes de questions disponibles et le bouton de lancement se mettent à jour ;
- le mode « questions ratées uniquement » applique également le filtre avant le démarrage ;
- les doublons d’identifiants sont écartés et les accents/variantes usuelles de difficulté sont normalisés.

Tests de non-régression : `node tests/qcm-filters.test.js`, `node tests/smoke-test.js`, `node scripts/validate-data.js`.
