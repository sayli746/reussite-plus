const normalizeText = value => String(value ?? "")
  .trim()
  .toLocaleLowerCase("fr-FR")
  .normalize("NFD")
  .replace(/[\u0300-\u036f]/g, "");

export function normalizeDifficulty(value) {
  const difficulty = normalizeText(value);
  if (["intermediaire", "intermediate", "moyen", "moyenne"].includes(difficulty)) return "intermediaire";
  if (["facile", "easy"].includes(difficulty)) return "facile";
  if (["difficile", "hard"].includes(difficulty)) return "difficile";
  return difficulty;
}

export function getChapterCounts(questions, difficulty = "") {
  const selectedDifficulty = normalizeDifficulty(difficulty);
  const chapters = new Map();
  for (const question of questions) {
    const chapter = String(question.chapitre ?? question.chapter ?? "").trim();
    if (!chapter) continue;
    if (selectedDifficulty && normalizeDifficulty(question.difficulte ?? question.difficulty) !== selectedDifficulty) continue;
    chapters.set(chapter, (chapters.get(chapter) || 0) + 1);
  }
  return [...chapters.entries()]
    .map(([value, count]) => ({ value, count }))
    .sort((a, b) => a.value.localeCompare(b.value, "fr"));
}

export function filterQcmQuestions(questions, {
  chapter = "",
  difficulty = "",
  reviewOnly = false,
  wrongIds = []
} = {}) {
  const selectedChapter = normalizeText(chapter);
  const selectedDifficulty = normalizeDifficulty(difficulty);
  const wrong = new Set(wrongIds);
  const seen = new Set();
  return questions.filter(question => {
    const questionChapter = normalizeText(question.chapitre ?? question.chapter ?? "");
    if (selectedChapter && questionChapter !== selectedChapter) return false;
    if (selectedDifficulty && normalizeDifficulty(question.difficulte ?? question.difficulty) !== selectedDifficulty) return false;
    if (reviewOnly && !wrong.has(question.id)) return false;
    const key = question.id || `${question.matiere || ""}|${questionChapter}|${question.question || ""}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
