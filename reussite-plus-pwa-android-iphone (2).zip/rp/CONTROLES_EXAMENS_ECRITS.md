# Réussite+ — contrôles et examens écrits

## Changements
- Ajout d'une page « Contrôles écrits » accessible par `#controles`.
- Remplacement de la page « Examens blancs » : elle propose désormais des réponses rédigées dans des champs texte, sans QCM.
- Contrôle par matière et chapitre ; examen blanc avec plusieurs questions tirées des fiches de cours de la matière/niveau.
- Durée indicative, sauvegarde locale des brouillons, rendu de copie, affichage des réponses données et éléments de correction, autoévaluation indicative par question, impression/PDF.
- Navigation ajoutée dans le menu principal.

## Limites importantes
- La correction des réponses longues n'est pas automatique : une note algorithmique serait peu fiable. L'élève peut comparer sa copie à des éléments de correction et s'autoévaluer.
- Le moteur s'appuie sur les données existantes dans `data/courses/`. Certaines fiches/exercices sont génériques et ne constituent pas encore des sujets disciplinaires authentiques, complets et validés par un enseignant. Avant de présenter les examens comme de vrais sujets prêts pour un examen officiel, il faut rédiger et relire des exercices spécifiques à chaque matière, chapitre et niveau, avec corrigés et barèmes adaptés.
- Le chronomètre fonctionne dans la page ouverte ; les brouillons restent dans le stockage local du navigateur et ne se synchronisent pas entre appareils.
- Aucun déploiement sur le site public n'a été effectué. Tests réalisés : `node --check app.js`, `tests/qcm-filters.test.js`, `tests/smoke-test.js`. Aucun test navigateur manuel n'a été effectué.
