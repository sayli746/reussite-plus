-- Schéma de base pour l'authentification Réussite+.
-- À exécuter dans Supabase SQL Editor avant d'activer l'inscription.
-- La clé service_role doit rester exclusivement dans les variables d'environnement Netlify.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 20),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "Les utilisateurs lisent leur profil" on public.profiles;
create policy "Les utilisateurs lisent leur profil"
  on public.profiles for select
  to authenticated
  using (auth.uid() = id);

drop policy if exists "Les utilisateurs modifient leur profil" on public.profiles;
create policy "Les utilisateurs modifient leur profil"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Préparation d'une table pour la progression cloud. Le code actuel enregistre
-- encore les résultats localement ; l'activation de la synchronisation nécessite
-- une implémentation et des tests supplémentaires avant usage en production.
create table if not exists public.user_progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  progress jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.user_progress enable row level security;

drop policy if exists "Les utilisateurs accèdent à leur progression" on public.user_progress;
create policy "Les utilisateurs accèdent à leur progression"
  on public.user_progress for all
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
